function pitagoras() {
}

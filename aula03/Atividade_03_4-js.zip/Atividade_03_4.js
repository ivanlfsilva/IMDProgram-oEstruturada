        function soma_e_escreve() {
            var x = Number(document.getElementById("entrada1").value);
            var y = Number(document.getElementById("entrada2").value);
            var z = x + y;    
            document.getElementById("saida").innerHTML = z;
        }

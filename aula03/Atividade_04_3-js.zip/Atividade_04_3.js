function positivos() {

}

function ler_entrada(campo) {

}

function escrever_saida(campo, valor) {

}

function maior(valor, limiar) {

}

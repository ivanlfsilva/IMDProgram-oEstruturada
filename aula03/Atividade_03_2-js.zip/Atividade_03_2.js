//var valorTotal     = 1;
//document.getElementById("saida").innerHTML = valorTotal;

//var valortotal     = 2;
//document.getElementById("saida").innerHTML = valortotal;

//var valor_total    = 3;
//document.getElementById("saida").innerHTML = valor_total;

//var 1_valor_total  = 4;
//document.getElementById("saida").innerHTML = 1_valor_total;

//var valor_total_1  = 5;
//document.getElementById("saida").innerHTML = valor_total_1;

//var $valor_total   = 6;
//document.getElementById("saida").innerHTML = $valor_total;

//var _valor_total   = 7;
//document.getElementById("saida").innerHTML = _valor_total;

//var valor-total    = 8;
//document.getElementById("saida").innerHTML = valor-total;

//var function       = 9;
//document.getElementById("saida").innerHTML = function;

//var object       = 9;
//document.getElementById("saida").innerHTML = object;

let x = 10;
var x = 20;
document.getElementById("saida1").innerHTML = a;
{
  let x = 30;
  var x = 40;
  document.getElementById("saida2").innerHTML = b;
}
document.getElementById("saida3").innerHTML = c;

x = "Deu ";
y = "Certo!!!";
z = x + y;
document.getElementById("saida").innerHTML = z;
